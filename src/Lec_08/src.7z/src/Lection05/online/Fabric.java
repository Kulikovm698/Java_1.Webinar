package Lection05.online;

import java.util.Random;

/**
 * Created by Aleksandr Gladkov [Anticisco]
 * Date: 28.04.2021
 */

public class Fabric {

    public static Random random = new Random();

    public static void main(String[] args) {
//        Hero hero1 = new Hero();
        Hero hero1 = new Hero(150, 50, "Patrik");

        System.out.println("random.toString() " + random.toString() );


//        Hero hero2 = new Hero(999, 1508, "Lancelot");
//
//        hero1.getSword().dealDamage();
//        System.out.println(hero1.getHealth());
//        System.out.println(hero1.getSpeed());
//        System.out.println(hero1.getName());
//
//        hero1.setName("Qwerty");
//        System.out.println(hero1.getName());

//        System.out.println(Hero.voice);
//        Hero.Sword.attack = 999999;
//        System.out.println(Hero.Sword.attack);

//        Hero.Sword sword = new Hero.Sword();
//        sword.dealDamage();

//        Hero hero3 = new Hero();
//        hero3.speak();
//        hero3.move();
//        hero3.damage();

        System.out.println("*************");



//        hero2.health = 999;
//        hero2.speed = 1508;
//        hero2.name = "Lancelot";

//        System.out.println(hero1.name);
//        System.out.println(hero1.health);
//        System.out.println(hero1.speed);
//        System.out.println(hero1.name + " has health " + hero1.health);
//
//        hero1.move();
//        hero1.speak();
//        hero1.damage();
//
//        hero1.sword.atkSpeed = 10.5f;
//        hero1.sword.attack = 169;
//        hero1.sword.weight = 900;
//
//
//
//        hero2.sword.attack = 9999;
//        hero2.sword.weight = 1500;
//        hero2.sword.atkSpeed = 10;
//
//        System.out.println(hero1.sword.attack + " " + hero2.sword.weight);
//
//        System.out.println(hero2.name + " has health " + hero2.health);
//
//        hero2.move();
//        hero2.speak();
//        hero2.damage();

//        System.out.println("I print hero - object:" + hero1);

    }

}

