package Lection07.online;

import Lection07.online.models.Soldier;

/**
 * Created by Aleksandr Gladkov [Anticisco]
 * Date: 12.05.2021
 */

public class DarkSoldier extends Soldier {

    public DarkSoldier(String name, int attack, float defense, float hp) {
        super(name, attack, defense, hp);
    }
}
