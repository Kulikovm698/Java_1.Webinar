package Lection07.online;

import Lection07.online.models.Soldier;

/**
 * Created by Aleksandr Gladkov [Anticisco]
 * Date: 12.05.2021
 */

public class LightSoldier extends Soldier {

    public LightSoldier(String name, int attack, float defense, float hp) {
        super(name, attack, defense, hp);
    }
}
