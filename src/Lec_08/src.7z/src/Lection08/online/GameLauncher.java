package Lection08.online;

/**
 * Created by Aleksandr Gladkov [Anticisco]
 * Date: 15.05.2021
 */

public class GameLauncher {

    public static void main(String[] args) {
        new MainWindow();
    }
}
